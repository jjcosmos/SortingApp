  _________              __  .__                    _____                 
 /   _____/ ____________/  |_|__| ____    ____     /  _  \ ______ ______  
 \_____  \ /  _ \_  __ \   __\  |/    \  / ___\   /  /_\  \\____ \\____ \ 
 /        (  <_> )  | \/|  | |  |   |  \/ /_/  > /    |    \  |_> >  |_> >
/_______  /\____/|__|   |__| |__|___|  /\___  /  \____|__  /   __/|   __/ v. 0.9.2
        \/                           \//_____/           \/|__|   |__|    


				by Jason Jackson

First, extract the contents of the zip folder to a location of your choice.

To set up the app, copy and paste the "sortingAppData" folder onto your desktop.
Feel free to edit, add, and delete the names in the text files, just be 
sure to keep this format:

name1
name2

When creating an additional period, just name the file "period" followed by the number
it corresponds to. 

e.g. "period9" (without the quotes)

Just be sure to have all text files in the "sortingAppData" folder on your desktop. 

When entering the desired period number into the program, you only need to type 
the number, not the full filename (for period 3, enter 3, etc..).

If you have any futher questions, feel free to 
contact me at jason.q.jackson@gmail.com

Happy Sorting!